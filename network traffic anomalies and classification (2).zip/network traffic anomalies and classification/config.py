iot23_scenarios_dir = 'E:\\machine-learning\\datasets\\iot23\\1_scenarios\\'
iot23_attacks_dir = 'E:\\machine-learning\\datasets\\iot23\\2_attacks\\'
iot23_data_dir = 'E:\\machine-learning\\datasets\\iot23\\3_data_v2\\'
iot23_experiments_dir = 'E:\\machine-learning\\datasets\\iot23\\4_experiments_v2\\'
